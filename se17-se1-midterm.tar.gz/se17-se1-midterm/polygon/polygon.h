#ifndef POLYGON_H
#define POLYGON_H
#include <vector>
#include <string>

namespace ac {

struct Point
{
    double x;
    double y;
};

struct Polygon
{
    int no;
    std::vector<Point> vertex;
    std::string fillColor;
    double perimeter;
};
extern bool compare(const Polygon &p1, const Polygon &p2);
extern std::istream &operator>> (std::istream &is,Polygon &p);
extern double perimeter(Polygon &p);


} // namespace ac

#endif // POLYGON_H
