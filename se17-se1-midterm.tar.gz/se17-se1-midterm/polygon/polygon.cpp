//The module that definite Polygon type and some other types and functions.
//author:stardust   date:2018-11-12
#include "polygon.h"

#include <iostream>
#include <sstream>
#include "hypot.h"
using std::string;      using std::istream;
using std::getline;     using std::istringstream;
using ac::Polygon;
using ac::Point;

double ac::perimeter(Polygon &p)
{
    double sum = 0;
    auto end = p.vertex.end();
    auto begin = p.vertex.begin();
    auto it = begin;
    while(it != end - 1){
            sum += ac::hypot((*(it + 1)).x - (*it).x,
                             (*(it + 1)).y - (*it).y);
            ++it;
    }
    sum += ac::hypot((*begin).x - (*it).x,
                     (*begin).y - (*it).y);
    return  sum;

}
//read a line from stream in turn，and construct a Polygon object
istream &ac::operator>>(istream &is, Polygon &p)
{
    for(string line; getline(is, line);){
        istringstream iss(line);
        if(iss >> p.no >> p.fillColor){
            p.vertex.clear();
            ac::Point point;
            while(iss >> point.x >> point.y){
                p.vertex.push_back(point);
            }
            break;
        }
    }

    return is;
}

//// The first ac::operator>> edition
//istream &ac::operator>>(istream &is, Polygon &p)
//{
//    std::string line;
//    while(getline(is, line) && "" == line) ;//jump over blank lines
//    if(is){
//        istringstream iss(line);
//        if(iss >> p.no >> p.fillColor){
//            p.vertex.clear();
//            Point point;
//            while(iss >> point.x >> point.y){
//                p.vertex.push_back(point);
//            }
//        }
//    }
//    return is;
//}

////another read solution
//istream &ac::operator>>(istream &is, Polygon &p)
//{
//    if(is >> p.no >> p.fillColor){
//        p.vertex.clear();
//        Point point;
//        while(is >> point.x >> point.y){
//            p.vertex.push_back(point);
//            while(' ' == is.peek())
//                is.get();
//            if('\n' == is.peek())
//                break;
//        }
//    }
//    return is;
//}

bool ac::compare(const Polygon &p1, const Polygon &p2)
{
    return p1.perimeter < p2.perimeter;
}
