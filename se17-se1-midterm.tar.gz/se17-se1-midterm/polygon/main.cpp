//The Program that reads some polygons, computes and outputs their perimeters.
//author:stardust   date:2018-11-12
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "polygon.h"

using std::ifstream;
using std::ofstream;
using std::vector;
using std::sort;
using ac::operator>>;
using ac::Polygon;
using ac::perimeter;

int main()
{
    vector<Polygon> Polygons;
    ifstream ifs{"../polygon/polygons.dat"};
    for(Polygon p; ifs >> p;){
        p.perimeter = perimeter(p);
        Polygons.push_back(p);
    }

    sort(Polygons.begin(), Polygons.end(), ac::compare);
    ofstream ofs{"../polygon/polygons-perimeter.dat"};
    ofs << "The perimeters of all Polygons: \n";
    for(auto &p:Polygons){
        ofs << p.no << "   " << p.fillColor << "     "
            << p.perimeter << std::endl;
    }

    return 0;
}
