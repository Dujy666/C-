#ifndef POINT_H
#define POINT_H

namespace ac {

struct Point
{
    double x;
    double y;
};

} // namespace ac

#endif // POINT_H
