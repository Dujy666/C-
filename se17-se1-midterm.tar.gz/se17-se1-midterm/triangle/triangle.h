//The module that definite Triangle type and some other types and functions.
//author:stardust   date:2018-11-12

#ifndef TRIANGLE_H
#define TRIANGLE_H
#include <array>

namespace ac {

struct Point
{
    double x;
    double y;
};

struct Triangle
{
    int no;
    std::array<Point, 3> vertex;
    std::string fillColor;
    double perimeter;
};

extern bool compare(const Triangle &t1, const Triangle &t2);
extern std::istream &operator>> (std::istream &is,Triangle &t);
extern double perimeter(const Triangle & t);


} // namespace ac

#endif // TRIANGLE_H
