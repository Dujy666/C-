#include "triangle.h"

#include <iostream>
#include "hypot.h"

double ac::perimeter(const ac::Triangle &t)
{
    return  ac::hypot(t.vertex[1].x - t.vertex[0].x,
            t.vertex[1].y - t.vertex[0].y) +

            ac::hypot(t.vertex[2].x - t.vertex[1].x,
            t.vertex[2].y - t.vertex[1].y) +

            ac::hypot(t.vertex[0].x - t.vertex[2].x,
            t.vertex[0].y - t.vertex[2].y);

}

std::istream &ac::operator>>(std::istream &is, ac::Triangle &p)
{
    is >> p.no >> p.fillColor
            >> p.vertex[0].x >> p.vertex[0].y
            >> p.vertex[1].x >>p.vertex[1].y
            >> p.vertex[2].x >>p.vertex[2].y;

    return is;
}


bool ac::compare(const ac::Triangle &t1, const ac::Triangle &t2)
{
    return t1.perimeter < t2.perimeter;
}
