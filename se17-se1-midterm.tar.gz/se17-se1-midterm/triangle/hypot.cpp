#include "hypot.h"
#include <cmath>

double ac::hypot(double x, double y)
{
    return std::sqrt(x*x + y*y);
}
