//The Program that reads some triangles, computes and outputs their perimeters.
//author:stardust   date:2018-11-12
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "triangle.h"

using std::ifstream;
using std::ofstream;
using std::vector;
using std::sort;
using ac::operator>>;
using ac::Triangle;

int main()
{
    vector<Triangle> triangles;
    ifstream ifs{"../triangle/triangles.dat"};
    for(Triangle t; ifs >> t;){
        t.perimeter = ac::perimeter(t);
        triangles.push_back(t);
    }

    sort(triangles.begin(), triangles.end(), ac::compare);
    ofstream ofs{"../triangle/triangles-perimeter.dat"};
    ofs << "The perimeters of all triangles: \n";
    for(auto &t:triangles){
        ofs << t.no << "   " << t.fillColor << "     "
            << t.perimeter << std::endl;
    }

    return 0;
}
