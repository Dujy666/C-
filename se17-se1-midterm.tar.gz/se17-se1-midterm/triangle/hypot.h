//The module that Computes the square root of the sum of the squares of x and y.
//author:stardust   date:2018-11-9
#ifndef HYPOT_H
#define HYPOT_H

namespace ac {
extern double hypot(double x, double y);
} // namespace ac
#endif // HYPOT_H
