#ifndef BASE_H
#define BASE_H
#include <iostream>

class Base
{
public:
    Base();
    void hide(int i){
        std::cerr << i << " using Base::hide." <<std::endl;
    }
    virtual void hideV(int i){
        std::cerr << i << " using Base::hideV." <<std::endl;
    }
};

#endif // BASE_H
