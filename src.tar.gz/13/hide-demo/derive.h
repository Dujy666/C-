#ifndef DERIVE_H
#define DERIVE_H
#include "base.h"

class Derive : public Base
{
public:
    Derive();
    void hide(double i){
        std::cerr << i << " using Derive::hide." <<std::endl;
    }
    virtual void hideV(double i){
        std::cerr << i << " using Devive::hideV." <<std::endl;
    }
};

#endif // DERIVE_H
