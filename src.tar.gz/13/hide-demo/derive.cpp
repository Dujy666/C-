#include "derive.h"

Derive::Derive()
{

}
