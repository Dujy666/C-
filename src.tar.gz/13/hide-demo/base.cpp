#include "base.h"

Base::Base()
{

}
