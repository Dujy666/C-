#include <iostream>
#include "derive.h"
using namespace std;

int main()
{
    Derive d;
    d.Derive::hide(1.5);
    d.Base::hideV(2.5);

    d.Base::hide(1.5);
    d.Derive::hideV(2.5);
    return 0;
}
