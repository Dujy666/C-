#ifndef GRADE_H
#define GRADE_H

#include <vector>

class Grade
{
public:
    Grade(double midterm, double final, std::vector<double> homework);
    virtual double score()=0;
    virtual ~Grade();
protected:
    double basicScore();
private:
    double m_midterm;
    double m_final;
    std::vector<double> m_homework;
};

#endif // GRADE_H
