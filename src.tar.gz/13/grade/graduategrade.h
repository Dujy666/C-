#ifndef GRADUATEGRADE_H
#define GRADUATEGRADE_H
#include "grade.h"

class GraduateGrade : public Grade
{
public:
    GraduateGrade(double midterm, double final, double thesis, std::vector<double> homework);
    virtual double score() override final;
private:
    double m_thesis;
};

#endif // GRADUATEGRADE_H
