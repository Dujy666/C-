#include "graduategrade.h"
#include "median.h"
#include <stdexcept>
using std::domain_error;

GraduateGrade::GraduateGrade(double midterm, double final, double thesis, std::vector<double> homework):Grade(midterm, final, homework), m_thesis{thesis}
{
    if(m_thesis < 0 && m_thesis > 100)
            throw domain_error("invalid thesis.");
}

double GraduateGrade::score()
{
    return  basicScore() + m_thesis * 0.2;
}

