#include "grade.h"
#include <stdexcept>
#include "median.h"

using std::domain_error;

Grade::Grade(double midterm, double final, std::vector<double> homework):m_midterm{midterm}, m_final{final}, m_homework{homework}
{
    if(m_midterm < 0 || m_midterm > 100)
        throw domain_error("invalid midterm.");

    if(m_final < 0 || m_final > 100)
        throw domain_error("invalid final.");

    if(m_homework.size() == 0){
            throw domain_error("Student has done no homework. ");
        }else{
            for(auto &h:m_homework)
                if(h < 0 && h > 100)
                    throw domain_error("invalid homework");
    }
}

Grade::~Grade()
{
    //no resource, empty destructor, only provide interface for Polymorphism clean.
}

double Grade::basicScore()
{
    return m_midterm * 0.2 + m_final * 0.4 + median(m_homework) *0.2;
}
