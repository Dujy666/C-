#include "uggrade.h"
#include <stdexcept>

using std::domain_error;

UgGrade::UgGrade(double midterm, double final, double practice, std::vector<double> homework):
    Grade(midterm,final, homework), m_practice{practice}
{
    if(m_practice < 0 || m_practice > 100)
        throw domain_error{"invalid practice."};
}

double UgGrade::score(){
    return  basicScore() + m_practice * 0.2;
}
