#ifndef UGGRADE_H
#define UGGRADE_H
#include "grade.h"
#include "median.h"

class UgGrade : public Grade
{
public:
    UgGrade(double midterm, double final, double practice, std::vector<double> homework);

    virtual double score();
private:
    double m_practice;
};

#endif // UGGRADE_H
