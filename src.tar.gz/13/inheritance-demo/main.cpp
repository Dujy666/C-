#include <iostream>
#include "derive.h"
using namespace std;

int main()
{
    Derive d;//is a关系不再成立
    d.iOp();
    return 0;
}
