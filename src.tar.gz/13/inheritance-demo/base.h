#ifndef BASE_H
#define BASE_H
#include <iostream>

class Base
{
public:
    Base();
    //iOp是接口操作
    virtual void iOp(){std::cerr << "Base::iOp()"<< std::endl;}
};

#endif // BASE_H
