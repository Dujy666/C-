#ifndef DERIVE_H
#define DERIVE_H
#include "base.h"

class Derive : protected Base
{
public:
    Derive();
    virtual void iOp(){std::cerr << "Derive::iOp()"<< std::endl;}
};

#endif // DERIVE_H
