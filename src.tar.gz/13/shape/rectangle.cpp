#include "rectangle.h"

Square::Square(double l, double w):m_length(l),m_width(w)
{
}

//Square::~Square(){}

//double Square::area() const
//{
//    return m_length*m_width;
//}
