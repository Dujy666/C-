#ifndef CANVAS_H
#define CANVAS_H
#include "shape.h"
#include <vector>

/* file canvas.h */
class Canvas {
public:
    void addShape(Shape *sp){
        _shapes.push_back(sp);
    }
    void refresh(){
        std::cerr << "refresh canvas...\n";
        for(auto &s:_shapes)
            s->draw();
        std::cerr << std::endl;
    }
private:
    std::vector<Shape *>  _shapes;
};

#endif // CANVAS_H
