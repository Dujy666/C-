#include "shape.h"


void Shape::vf()
{

}
