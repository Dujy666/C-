#ifndef CIRCLE_H
#define CIRCLE_H
#include <iostream>
#include "shape.h"


/* file circle.h */
class Circle : public Shape
{
public:
    Circle(Point origin, double r = 0.0)
        :Shape(origin), m_r(r){}
    virtual void draw() override final;
    virtual void vf()override;
    virtual ~Circle()override
    {
        std::cerr << "delete a circle.";
    }
public:
    double m_r;
};

#endif // CIRCLE_H


void Circle::draw()
{
    std::cerr << "Drawing a Cirle in ("
              << origin().x << ","
              << origin().y << "), radius = "
              << m_r << std::endl;
}

void Circle::vf()
{

}
