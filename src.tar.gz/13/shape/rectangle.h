#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <iostream>
#include "shape.h"

/* file rectangle.h */
class Rectangle : public Shape
{
public:
    Rectangle(Point p, double l = 0.0,
              double w = 0.0):Shape{p},
              m_length(l), m_width(w){}

    virtual void draw() override{
        std::cerr << "Drawing a Square in ("
                  << origin().x <<","
                  << origin().y <<"),"
                  << " length = " << m_length
                  <<", width ="
                  << m_width << std::endl;
    }
    virtual ~Rectangle()override{
        std::cerr << "delete a rectangle.";
    }
    virtual void vf()override;
private:
    double m_length;
    double m_width;
};

#endif // RECTANGLE_H

