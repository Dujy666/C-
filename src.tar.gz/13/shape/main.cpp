#include <iostream>
#include "circle.h"
#include "rectangle.h"
#include "shape.h"
#include "canvas.h"

using namespace std;

/* file main.cpp */
int main()
{
    Point p1 = {0.0, 0.0};
    Shape *ps = new Circle(p1, 10.0);
    delete ps;

    Point p2 = {1.0, 1.0};
    ps = new Rectangle(p2, 5.0, 7.0);
    delete ps;
    ps = nullptr;

    return 0;
}
