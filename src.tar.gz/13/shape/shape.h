#ifndef SHAPE_H
#define SHAPE_H
#include <iostream>

/* file shape.h */
struct Point{
    double x;
    double y;
};

class Shape
{
public:
    Shape(Point origin):
        m_origin(origin){}
    virtual void vf();
    virtual ~Shape(){}

    Point origin(){return m_origin;}
    void move(Point origin){
        m_origin = origin;
    }
    virtual void draw()=0;
private:
    Point m_origin;
};

#endif // SHAPE_H

