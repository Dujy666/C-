#ifndef SHAPE_H
#define SHAPE_H
#include "point.h"

class Shape
{
public:
    Shape(Point o);     //构造函数声明，通常不会被继承

    void move(Point p); //普通函数声明，可被继承
    //    void noMethod();    //普通函数声明，但是没有提供方法，调用它时会编译失败

    //    Point origin() const;

protected:
    //    void hideOp();  //隐藏的操作，不是接口的一部分，调用时不可见
    Point m_origin;     //属性描述，可被继承
};

#endif // SHAPE_H


