#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "shape.h"

class Rectangle : public Shape
{
public:
    Rectangle(Point origin, double width, double length);

    void display(); //子类特有的操作

private:
    double m_width;   //特有属性
    double m_length;   //特有属性
};

#endif // RECTANGLE_H
