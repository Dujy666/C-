#include "rectangle.h"
#include <iostream>

using std::cerr;

Rectangle::Rectangle(Point origin, double width, double length):
    Shape(origin),m_width{width}, m_length{length}
{}
