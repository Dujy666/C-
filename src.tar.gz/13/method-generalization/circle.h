#ifndef CIRCLE_H
#define CIRCLE_H
#include "shape.h"

class Circle : public Shape
{
public:
    Circle(Point p, double r); //构造函数
    void display();  //子类操作
private:
    double m_radius; //特有属性
};

#endif // CIRCLE_H
