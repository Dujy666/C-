#include <iostream>
#include "point.h"
#include "circle.h"
#include "rectangle.h"

using namespace std;

int main()
{
    Point p(1.0, 1.0);
    cerr << "Point p(1.0, 1.0);\n";

    cerr << "-----------------\n\n";
    cerr << "Shape s(p);\n";
    Shape s(p); //s是一个Shape对象，尽管语义上并不成立
    cerr << "\ns.move(Point(2.0, 2.0));\n";
    s.move(Point(2.0, 2.0)); //OK，调用Shape自身操作，静态绑定到自身的方法
    //    s.hideOp(); //错误！不从允许调用私有操作
    //    s.display();//错误！display()没有在Shape接口中声明
    //    s.noMethod();//错误！该操作调用不能进行静态绑定，编译器会报"未定义的引用"错误

    cerr << "-----------------\n\n";
    cerr << "Circle c(p, 10.0);\n";
    Circle c(p, 10.0); //c是一个Circle对象，内嵌了一个Shape对象
    cerr << "\nc.move(Point(3.0, 3.0)); \n";
    c.move(Point(3.0, 3.0));  //OK，调用继承的父类操作，静态绑定到继承的父类方法
    cerr << "\nc.display(); \n";
    c.display();      //OK，调用子类的自身操作，静态绑定到自身的方法

    cerr << "-------------------------------\n\n";
    cerr << "Shape *ps = &c;\n";

    Shape *ps = &c;
    cerr << "\nps->move(p); \n";
    ps->move(p);       //OK，通过指针调用Shape自身的操作，静态绑定到自身的方法
    //    ps->display();     //错误！Shape的接口没有操作display()

    cerr << "-----------------\n\n";
    cerr << "Circle *pc = &c;\n";
    Circle *pc = &c;
    cerr << "\npc->move(Point(5.0, 5.0)); \n";
    pc->move(Point(5.0, 5.0));  //OK，通过指针调用继承的父类Shape的操作，静态绑定到继承的父类方法
    cerr << "\npc->display(); \n";
    pc->display();      //OK,通过指针调用子类Circle的自身操作，静态绑定到自身的方法

    return 0;
}



//int main()
//{
//    Point p(1.0, 2.0);

//    Shape s(p); //s是一个Shape对象，尽管语义上并不成立
//    cout<< "s.move(Point(2.0, 2.0));\ns.display();\n    ";
//    s.move(Point(2.0, 2.0)); //OK，调用Shape自身操作，静态绑定到自身的方法
//    //    s.hideOp(); //错误！不允许调用私有操作
//    //    s.display();//错误！display()没有在Shape接口中声明
//    //    s.noMethod();//错误！该操作调用不能进行静态绑定，编译器会报"未定义的引用"错误
//    cout << "    can't invoke ps->display();\n"<< endl;

//    Circle c(p, 10.0); //c是一个Circle对象，内嵌了一个Shape对象
//    cout<< "c.move(Point());\nc.display();\n    ";
//    c.move(Point());  //OK，调用子类的自身操作，静态绑定到C自身的方法
//    cout << "    ";
//    c.display();      //OK，调用子类的自身操作，静态绑定到自身的方法
//    cout << endl;
//    cout<< "c.Shape::move(Point(3.0, 3.0));\nc.display();\n    ";
//    c.Shape::move(Point(3.0, 3.0));
//    cout << "    ";
//    c.display();

//    cout << endl;
//    Shape *ps = &c;
//    cout << "ps->move(p);\nps->display()\n    ";
//    ps->move(p);       //OK，通过指针调用Shape自身的操作，静态绑定到自身的方法
//    //    ps->display();     //错误！Shape的接口没有操作display()
//    cout << "    can't invoke ps->display();\n"<< endl;
//    Circle *pc = &c;
//    cout << "pc->move(Point());\npc->display();\n    ";
//    pc->move(Point());
//    cout << "    ";
//    pc->display();      //OK,通过指针调用Circle自身的操作，静态绑定到自身的方法

//    return 0;
//}
