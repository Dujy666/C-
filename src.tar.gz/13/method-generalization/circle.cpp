#include "circle.h"
#include <iostream>
using std::cerr;   using std::endl;

Circle::Circle(Point p, double r):
    Shape(p), m_radius{r}
{}

void Circle::display() //特有的方法表达了特定于子类的行为细节
{
    cerr << "display an Circle：origin = " +
            m_origin.toString() << +
            ", radius = " << m_radius
         <<" using Circle::display()."<< endl;
}


