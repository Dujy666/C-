#include "shape.h"
#include <iostream>
using std::cerr;    using std::endl;

Shape::Shape(Point p):m_origin{p}{}

void Shape::move(Point p)//泛化的方法，被子类继承
{
    cerr << "moving to a new Point: "
             +p.toString()
             +" using Shape::move()."<< endl;
    m_origin = p;
}

