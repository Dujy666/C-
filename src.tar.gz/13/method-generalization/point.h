#ifndef POINT_H
#define POINT_H
#include <string>
#include <iostream>
#include <sstream>
using std::cerr;

class Point
{
public:
    Point(double x = 0.0, double y = 0.0):
        m_x{x}, m_y{y}{}

    std::string toString(){
        std::ostringstream oss;
        oss << "(" << m_x <<", " << m_y << ")";

        return oss.str();
    }
private:
    double m_x;
    double m_y;
};

#endif // POINT_H
