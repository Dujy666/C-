#include "point.h"
#include <sstream>

Point::Point(double x, double y):
    m_x{x}, m_y{y}
{}

std::string Point::toString(){
    std::ostringstream oss;
    oss << "(" << m_x <<", " << m_y << ")";

    return oss.str();
}
