#ifndef RECTANGLE_H
#define RECTANGLE_H
#include "shape.h"

class Rectangle : public Shape
{
public:
    Rectangle(Point origin,
              double width, double length);
    virtual ~Rectangle();

    virtual void display(); //继承的父类操作声明

private:
    double m_width;   //特有属性
    double m_length;   //特有属性
};

#endif // RECTANGLE_H
