#include "circle.h"
#include <iostream>
using std::cerr;
using std::endl;

Circle::Circle(Point p, double r):
    Shape(p), m_radius{r}
{}

/*特有的方法表达了特定于子类的行为细节*/
void Circle::display()
{
    cerr << "    display a Circle：";
    displayShape();
    cerr << ", radius = " << m_radius << " using Circle::display() method" << endl << endl;
}

Circle::~Circle()
{
    cerr << "destroy a Cirle.\n";
}


