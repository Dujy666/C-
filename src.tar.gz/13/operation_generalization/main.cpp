#include <iostream>
#include "circle.h"
#include "rectangle.h"
using namespace std;

int main()
{
    Point p(1.0, 1.0);
    cerr << "Point p(1.0, 1.0);\n";

    cerr << "-----------------\n\n";
    //    Shape s(p); //Error，Shape是抽象类，无法创建s
    cerr << "Circle c(p, 10.0);\n";
    Circle c(p, 10.0); //c是一个Circle对象，内嵌了一个Shape对象
    cerr << "c.display();//common operation\n";
    c.display(); //通常不建议这样调用所继承的抽象操作，这里静态绑定到了虚函数方法

    cerr << "-------------------------------\n\n";
    cerr << "Shape *ps = &c;\n";
    Shape *ps = &c;
    cerr << "ps->move(p);\n";
    ps->move(p);    //OK，通过指针调用自身的操作，静态绑定到自身的方法
    cerr << "ps->display();//polymorphism operation\n";
    ps->display();  //OK，多态调用：通过指针调用自身操作，动态绑定到子类的方法
    cerr << "-------------------------------\n\n";
    cerr << "ps = new Rectangle(Point(), 5.0, 5.0);\n";
    ps = new Rectangle(Point(), 5.0, 5.0);
    cerr << "ps->move(p);\n";
    ps->move(p);    //OK，通过指针调用自身的操作，静态绑定到自身的方法
    cerr << "ps->display();polymorphism operation\n";
    ps->display();  //OK，多态调用：通过指针调用自身操作，动态绑定到子类的方法
    ps = new Circle{p, 15.0};

    cerr << "_____________________\n";
    delete ps;
    cerr << "----------------------\n";
    //    s = c;      //强制类型转换
    //    s.display();
    //    c.display();

    return 0;
}


//void f(){

//    Shape *ps = nullptr; //ps的静态类型为Shape *
//    Shape *pc = new Circle(); //pc的静态类型为Shape *，动态类型为Circle *
//    Shape *pr = new Rectangle();//pr的静态类型为Shape *，动态类型为Rectangle *
//    ps = pc;  //ps的动态类型现在是Circle *
//    ps = pr;  //ps的动态类型现在是Rectangle *

//}
