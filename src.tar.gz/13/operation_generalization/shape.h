#ifndef SHAPE_H
#define SHAPE_H
#include "point.h"
#include <iostream>

class Shape
{
public:
    Shape(Point o);     //构造函数声明，通常不会被继承
    void move(Point p); //普通函数声明，可被继承
    virtual void display() = 0; //抽象操作(纯虚函数)，可被继承
    virtual ~Shape();

    //所有protected成员可被继承，对所有子类成员可见
protected:
    void displayShape(); //子类共享的接口，内部的修改通常不会引起它的修改；
                                //有必要时，还可以重载一个接口
    //    Point origin() const; //尽量不要用getter
    //    void setOrigin(Point p); //尽量不要用setter
//        Point m_origin;  //尽量不要声明所有子类可见的变量

    //仅仅本类的成员可见，被封装在本类的范围，维护代价低
private:
    Point m_origin;     //private属性描述，可被继承，但其对子类成员不可见
};

#endif // SHAPE_H


