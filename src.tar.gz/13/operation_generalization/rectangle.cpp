#include "rectangle.h"
#include <iostream>

using std::cerr;    using std::endl;

Rectangle::Rectangle(Point origin,
                     double width, double length):
    Shape(origin),m_width{width}, m_length{length}
{}

Rectangle::~Rectangle()
{
    cerr << "destroy a Rectangle.\n";
}

/*特有的方法表达了特定于子类的行为细节*/
void Rectangle::display()
{
    cerr << "    display a Rectangle: ";
    displayShape();
    cerr <<", width = " << m_width <<"," <<
           "length = " << m_length << " using Rectangle::display() method" << endl << endl;
}

