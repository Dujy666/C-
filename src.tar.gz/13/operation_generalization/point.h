#ifndef POINT_H
#define POINT_H
#include <string>

class Point
{
public:
    Point(double x = 0.0, double y = 0.0);

    std::string toString();
//    void fun_cant_be_used();//普通(成员)函数如果不使用，可以只声明，不提供定义。
private:
    double m_x;
    double m_y;
};

#endif // POINT_H
