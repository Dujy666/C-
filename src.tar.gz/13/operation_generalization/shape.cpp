#include "shape.h"
#include <iostream>
using std::cerr;
using std::endl;

Shape::Shape(Point p):m_origin{p}{}

void Shape::move(Point p) //泛化的方法，被子类继承
{
    cerr << "    moving to Point new Point " +
            p.toString() << endl << endl;
    m_origin = p;
}

Shape::~Shape()
{
    //omit some statements that free own resources.
}

void Shape::displayShape()
{
   cerr <<  "origin = " +
                m_origin.toString();
}


//Point Shape::origin() const
//{
//    return m_origin;
//}

//void Shape::setOrigin(Point p)
//{
//    m_origin = p;
//}
