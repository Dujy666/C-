#ifndef BASE_H
#define BASE_H


class Base
{
public:
    Base(){}
    virtual ~Base();
private:
    int i{10};
};

#endif // BASE_H
