#ifndef COMPLEX_H
#define COMPLEX_H
#include <string>

class Complex
{
public:
    constexpr Complex(const double re = 0.0,
                      const double im = 0.0);

    constexpr Complex operator+(const Complex c){
        return Complex(m_real + c.m_real, m_imag + c.m_imag);
    }
    // omit other code
    std::string complexToString() const;

private:
    double m_real;
    double m_imag;
};



#endif // COMPLEX_H

//int k = 0;   //k不是常量表达式
//const int width = k; //width不是常量表达式
//const int max_files = 20;     //max_files是常量表达式
//const int limit = max_files + 1;  //limit是常量表达式


//int var = 17;// var不是常量
//const int width = var; // width不是常量表达式
//double sum(const vector<double>&);// sum函数不会修改它的参数
//vector<double> v {1.2, 3.4, 4.5};// v不是一个常量
//const double s1 = sum(v);// OK:在运行时求值

//const int dmv = 17;// dmv是常量表达式
//const int limit = dmv + 1;  // limit是常量表达式
//constexpr double square(const int); // square是constexpr函数
//constexpr double max1 = 1.4*square(dmv);// 如果square(17)是常量表达式，则正确
//constexpr double max2 = 1.4*square(var);// error : var不是常量表达式
//const double max3 = 1.4*square(var);// OK, 可以在运行时求值






//string s1("hello, ");// s1保存了字符串"hello,"
//string s2("world");  // s2保存了字符串"world"
//string s3 = s1 + s2; // s1 + s2使用了操作符+实现了字符串的连接，
//                     // +操作产生的字符串临时对象保存了字符串"hello, world"
//                     // 该临时对象将会作为初始值复制给s3




//void A::operator=(const A &o){//隐式生成的浅赋值重载函数
//    m1 = o.m1;
//    m2 = o.m2;
//    …;
//    mi = o.mi;
//}

//class A {
//public:
//    //...
//    void operator=(const A&) = delete;
//    void operator&() = delete;
//    void operator,(const A&) = delete;
//    //...
//};

//void f(X a, X b)
//{
//    a = b;// error: no operator=()
//    &a;// error: no operator&()
//    a,b;// error: no operator,()

//    int &&rr1 = 42;//ok: literals are rvalues
//    int &&rr2 = rr1;//error: the expression rr1 is an lvalue!


//    int l=rr2；

//    int i = 42;
//    int &r = i; //ok:r引用i
//    int &&rr = i;//error:不能绑定一个右值引用到一个左值
//    int &r2 = i * 42;//error: i*42是一个右值
//    const int &r3 = i * 42;//ok:可以绑定一个const引用到一个右值
//    int &&rr2 = i * 42;//ok:绑定rr2到乘法结果临时值上

//    int &&i = 20; //这里使用了右值引用来绑定了一个临时字面量20,
//                   //使得临时对象不必马上销毁，可以重复使用，
//                   //这也是右值引用的目的之一。

//    i = 20;  //i是左值，20是临时值，即右值字面量
//    k = i + 10*j   //10*j、i+(10*j)都是右值临时对象
//    X f(){ X x; …; return x;}   void f(){ X x1 = f();}  //f()值临时对象是右值

//    r i
//            rr
//            r2
//            r3
//            rr2



//}

//class Complex
//{
//    friend std::ostream &operator<<(std::ostream &os, const Complex &c)
//    {
//        if(c.m_imag >= 0)
//            return os << c.m_real << "+" <<c.m_imag << "i";
//        else
//            return os << c.m_real << c.m_imag << "i";
//    }

//public:
//    Complex(const double r = 0.0, const double i = 0.0)
//        :m_real{r}, m_imag{i}{}
//    Complex(const Complex &other)
//        :m_real{other.m_real}, m_imag{other.m_imag}{}

//    Complex operator+(const Complex &c) const
//    {
//        return Complex{m_real + c.m_real, m_imag + c.m_imag};
//    }
//private:
//    double m_real;
//    double m_imag;
//};


//#endif // COMPLEX_H
