#include "Complex.h"
using std::to_string;

//参数构造函数和默认构造函数2合1
Complex::Complex(const double re,
                 const double im)
    :m_real{re}, m_imag{im}{}

//Complex::Complex(double re, double im)
//{

//}

std::string Complex::complexToString() const
{
    return to_string(m_real) + " " + to_string(m_imag) +"i";
}

