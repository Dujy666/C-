#include "Complex.h"
#include <iostream>

using namespace std;

int main()
{
    Complex c1(1.0, -1.5); //OK, has matching parameter constructor
    Complex c2(-1.0, 2.0);

    cout << "c1 is " << c1.complexToString() << endl;
    cout << "c2 is " << c2.complexToString() << endl;
    cout << "c1 + c2 is " << (c1 + c2).complexToString() << endl;
    return 0;
}

