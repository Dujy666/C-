#include "page.h"
#include <iostream>
#include <exception>
using std::domain_error;
using std::cerr;

Page::Page(int no, int lines):m_no{no}
{
    if(no < 1)
        throw domain_error("invalid line number.");

    for(int i = 1; i < lines + 1; i++)
        _lines.push_back(new Line(i));

    cerr << "  call Page's parameter constructor.";
    cerr << " This Page has " << _lines.size() << " lines now.\n";
}

Page::Page(const Page &o):
    m_no{o.m_no}
{
    for(auto l:o._lines)
        _lines.push_back(new Line{*l});
    cerr << "  call Page's copy constructor.";
    cerr << " This Page has " << _lines.size() << " lines now.\n";
}


Page::Page(Page &&o)noexcept:
    m_no{o.m_no},_lines{o._lines}
{
    o._lines.clear();//为了正常销毁源对象
    cerr << "  call Page's move constructor.";
    cerr << " This Page has " << _lines.size() << " lines now.\n";
}

Page &Page::operator=(const Page &o)
{
    cerr << "  call Page's operator=(Page &).";
    m_no=o.m_no;
    cerr << "  _lines=" <<_lines.size() <<  " before erase,";
    for(auto l:_lines){
        delete l;
    }
    _lines.clear();
    cerr << "  o._lines=" <<o._lines.size() <<  " before copy,";
    for(auto l:o._lines){
        _lines.push_back(new Line{*l});
    }
    cerr << "  o._lines=" << o._lines.size() <<  " after copy,";
    cerr << "  _lines="<< _lines.size() << " now.\n";

    return *this;
}

Page &Page::operator=(Page &&o) noexcept
{
    cerr << "  call Page's operator=(Page &&).";
    m_no=o.m_no;
    cerr << "  _lines=" << _lines.size() <<  " before erase,";
    for(auto l:_lines){
        delete l;
    }
    cerr << "  o._lines=" << o._lines.size() <<  " before move,";
    _lines = o._lines;
    o._lines.clear();
    cerr << "  o._lines=" << o._lines.size() <<  " after move,";
    cerr << " This Page has " <<  _lines.size() << " lines now.\n";

    return *this;
}

Page::~Page()
{
    cerr << "  call Page's destructor.";
    for(auto l:_lines){
        delete l;
        l = nullptr;
    }
    cerr << " This Page had " << _lines.size() << " lines before.\n";
}

