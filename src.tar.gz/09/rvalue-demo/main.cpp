#include <iostream>
using std::cout;
using std::endl;

void process_value(/*const*/ int& i) {
    cout << "LValue processed: " << i << endl;
}

void process_value(int&& i) {
    cout << "RValue processed: " << i << endl;
}

void forward_value(int&& i) {
    process_value(i);
}

int main() {
    int a = 0;
    process_value(a);
    process_value(1);//临时对象将作为右值处理
    forward_value(2);//临时对象通过一个接受右值的函数
                    //右值引用本身是左值，13行将右值引用传递给
                    //process_value函数时，将调用其左值引用的重载版本。
}

