#include <stdexcept>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <ios>
#include "median.h"
#include "grade.h"

using std::cin;             using std::sort;
using std::cout;            using std::domain_error;
using std::endl;            using std::string;
using std::setprecision;    using std::vector;
using std::istream;         using std::max;

extern Grade *CreateGrade(istream &is);
extern bool compare(const Grade &s1, const Grade &s2);

int main()
{
    vector<Grade *> courseGrade;

    string::size_type maxlen = 0;
    //read and store all the records,and find the length of the longest name
    while(cin){
        try{
            Grade *gp = CreateGrade(cin);
            if(!gp){
                maxlen = max(maxlen, gp->name().size());
                courseGrade.push_back(*gp);
            }
        }catch(domain_error e){
            cout << e.what();

        }
    }
    //alphabetize the records
    sort(courseGrade.begin(),courseGrade.end(), compare);
    //output the grade report
    cout << "The grade report of 'Software Engineering 1' courseware.\n";
    for(auto &gp:courseGrade){
        cout << gp->name()
             << string(maxlen + 1 - gp->name().size(), ' ');
        //compute and write the grade
        double final_grade = gp->score();
        auto prec = cout.precision();
        cout << setprecision(3) << final_grade << setprecision(prec);

        cout << endl;
    }

    return 0;
}

bool compare(const Grade *s1, const Grade *s2)
{
    return s1->name() < s2->name();

}

Grade *CreateGrade(istream &is){
    //read and store the student'name and midterm and final exam grade
    std::string name;
    double midterm;
    double final;
    std::vector<double> hw;

    is >> name >> midterm >> final;
    //read and store all the student's homework grades
    if(is){
        // hw.clear();
        double x;
        while(is >> x)
            hw.push_back(x);
        is.clear();
        return new Grade(name, midterm, final, hw);
    }
    if(!is.eof())
        is.clear();

    return nullptr;
}

//istream &read(istream &is, Grade &s)
//{
//    //read and store the student'name and midterm and final exam grade
//    std::string name;
//    double midterm;
//    double final;
//    std::vector<double> hw;

//    is >> name >> midterm >> final;
//    //read and store all the student's homework grades
//    if(is){
//        // hw.clear();
//        double x;
//        while(is >> x)
//            hw.push_back(x);
//        is.clear();

//    }
//    return is;
//}


//void f(){

//    Grade g;
//    Grade *gp = new g;
//    Grade &gr = g;
//    g.setName("Nils");
//    gp->setName("Caroto");
//    std::cout << gr.name();

//    std::vector<Grade> courseGrade;
//    courseGrade.push_back(g);
//    courseGrade.push_back(*gp);

//}








