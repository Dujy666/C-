#ifndef GRADE_H
#define GRADE_H

#include <vector>
#include <string>

class Grade
{
public:
    Grade(std::string name, double midterm,
          double final, std::vector<double> homework);

    double score();
    std::string name() const { return m_name; }
private:
    std::string m_name;
    double m_midterm;
    double m_final;
    std::vector<double> m_homework;
};

#endif // GRADE_H


