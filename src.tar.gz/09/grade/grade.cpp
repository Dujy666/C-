#include "grade.h"

#include <istream>
#include <stdexcept>
#include "median.h"

using std::domain_error;
using std::vector;
using std::string;


Grade::Grade(std::string name, double midterm,
             double final, std::vector<double> homework)
    : m_name{name}, m_midterm{midterm},
      m_final{final}, m_homework{homework}
{
    if(midterm < 0 && midterm > 100)
        throw domain_error("invalid midterm.");

    if(final < 0 && final > 100)
        throw domain_error("invalid final.");

    if(m_homework.size() == 0){
        throw domain_error("Student has done no homework. ");
    }else{
        for(auto &h:m_homework)
            if(h < 0 && h > 100)
                throw domain_error("invalid homework");
    }
}

double Grade::score()
{
    return  0.2 * m_midterm +
            0.4 * m_final +
            0.4 * median(m_homework);
}
