#ifndef COMPLEX_H
#define COMPLEX_H

class Complex
{
public:
    Complex(double re, double im);
    // omit other code
    double imag() const;
    double real() const;

private:
    double m_real;
    double m_imag;
};

#endif // COMPLEX_H
