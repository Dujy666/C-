#include <iostream>
#include "complex.h"

using namespace std;
void f(Complex &&rc)
{
    cout << rc.real() <<" + " << rc.imag() << "i" << " in fr" << endl;
}

void f(Complex &lc)
{
    cout << lc.real() <<" + " << lc.imag() << "i" << " in fl" << endl;
}

int main()
{
    f(Complex(2.5, 1.5));

    Complex lc1(1.0, 3.0);
    f(lc1);
    //    f((Complex &&)lc1);

    return 0;
}



