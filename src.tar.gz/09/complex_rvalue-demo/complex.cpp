#include "complex.h"

Complex::Complex(double re,
                 double im):
    m_real{re}, m_imag{im}
{}

double Complex::imag() const
{
    return m_imag;
}

double Complex::real() const
{
    return m_real;
}
