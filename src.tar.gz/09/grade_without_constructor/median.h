#ifndef MEDIAN_H
#define MEDIAN_H
#include <vector>

extern double median(std::vector<double> vec);

#endif // MEDIAN_H
