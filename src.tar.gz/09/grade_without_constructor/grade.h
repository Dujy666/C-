#ifndef GRADE_H
#define GRADE_H

#include <vector>
#include <string>

class Grade
{
public:
    double score(); //common member function

    //getter member functions
    std::string name() const;
    double midterm() const;
    double final() const;
    std::vector<double> homework() const;

    //getter member functions
    void setName(const std::string &name);
    void setMidterm(double midterm);
    void setFinal(double final);
    void setHomework(const std::vector<double> &homework);

private:
    std::string m_name;
    double m_midterm;
    double m_final;
    std::vector<double> m_homework;
};

#endif // GRADE_H


