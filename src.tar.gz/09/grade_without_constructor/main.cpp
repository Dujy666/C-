#include <stdexcept>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <ios>
#include "median.h"
#include "grade.h"

using std::cin;             using std::sort;
using std::cout;            using std::domain_error;
using std::endl;            using std::string;
using std::setprecision;    using std::vector;
using std::istream;         using std::max;

extern std::istream &read(std::istream &is, Grade &s);
extern bool compare(const Grade &s1, const Grade &s2);

int main()
{
    vector<Grade> courseGrade;
    Grade grade;
    string::size_type maxlen = 0;
    //read and store all the records,and find the length of the longest name
    while(read(cin, grade)){
        maxlen = max(maxlen, grade.name().size());
        courseGrade.push_back(grade);
    }
    //alphabetize the records
    sort(courseGrade.begin(),courseGrade.end(), compare);
    //output the grade report
    cout << "The grade report of 'Software Engineering 1' courseware.\n";
    for(auto &g:courseGrade){
        cout << g.name()
             << string(maxlen + 1 - g.name().size(), ' ');
        //compute and write the grade
        try{
            double final_grade = g.score();
            auto prec = cout.precision();
            cout << setprecision(3) << final_grade << setprecision(prec);
        }catch(domain_error e){
            cout << e.what();
        }
        cout << endl;
    }

    return 0;
}

bool compare(const Grade &s1, const Grade &s2)
{
    return s1.name() < s2.name();

}

istream &read(istream &is, Grade &s)
{
    //read and store the student'name and midterm and final exam grade
    std::string name;
    double midterm;
    double final;
    std::vector<double> hw;

    is >> name >> midterm >> final;
    //read and store all the student's homework grades
    if(is){
        // hw.clear();
        double x;
        while(is >> x)
            hw.push_back(x);
        is.clear();

        s.setName(name);
        s.setMidterm(midterm);
        s.setFinal(final);
        s.setHomework(hw);
    }
    return is;
}


//void f(){

//    Grade g;
//    Grade *gp = new g;
//    Grade &gr = g;
//    g.setName("Nils");
//    gp->setName("Caroto");
//    std::cout << gr.name();

//    std::vector<Grade> courseGrade;
//    courseGrade.push_back(g);
//    courseGrade.push_back(*gp);

//}





