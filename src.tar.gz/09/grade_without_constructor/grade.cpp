#include "grade.h"

#include <istream>
#include <stdexcept>
#include "median.h"

using std::domain_error;
using std::vector;
using std::istream;
using std::string;

double Grade::score()
{
    return  0.2 * m_midterm +
            0.4 * m_final +
            0.4 * median(m_homework);
}

std::string Grade::name() const
{
    return m_name;
}

double Grade::midterm() const
{
    return m_midterm;
}

double Grade::final() const
{
    return m_final;
}

std::vector<double> Grade::homework() const
{
    return m_homework;
}

void Grade::setName(const std::string &name)
{
    m_name = name;
}

void Grade::setMidterm(double midterm)
{
    if(0 <= midterm && midterm <= 100)
        m_midterm = midterm;
    else
        throw domain_error("invalid midterm.");
}

void Grade::setFinal(double final)
{
    if(0 <= final && final <= 100)
        m_final = final;
    else
        throw domain_error("invalid final.");
}

void Grade::setHomework(const std::vector<double> &homework)
{
    if(homework.size() != 0){
        for(auto &h:homework)
            if(0 <= h && h <= 100)
                m_homework.push_back(h);
            else
                throw domain_error("invalid homework");
    }else
        throw domain_error("Student has done no homework. ");
}

