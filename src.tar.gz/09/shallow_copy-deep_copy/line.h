#ifndef LINE_H
#define LINE_H
#include <string>

class Line
{
public:
    Line(int lineNo):m_no{lineNo + 1}{}
    void writeChar(std::string chars);
    std::string chars(){
        return m_chars;
    }
private:
    int m_no;
    std::string m_chars;
};

#endif // LINE_H

//class Line
//{
//    Line(int lineNo);
//    void writeChars(std::string chars);
//    //other lines
//    int m_no;
//    std::string m_chars;
//};
