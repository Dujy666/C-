#include "line.h"

void Line::writeChar(std::string chars){
    m_chars = chars;
}
