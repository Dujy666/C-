#include <iostream>
#include "page.h"
#include "line.h"

using namespace std;

int main()
{
    Page p1(1,2);
    p1.getLine(1)->writeChar("hello");
    p1.getLine(2)->writeChar("world");
    cout << p1.getLine(1)->chars() << " ";
    cout << p1.getLine(2)->chars() << endl;
    cout << "-------deep copy---------" << endl;
    Page p1_cp = p1;
    p1_cp.getLine(1)->writeChar("meet");
    p1_cp.getLine(2)->writeChar("C++");
    cout << p1.getLine(1)->chars() << " ";
    cout << p1.getLine(2)->chars() << endl;
    cout << p1_cp.getLine(1)->chars() << " ";
    cout << p1_cp.getLine(2)->chars() << endl;

    return 0;
}
