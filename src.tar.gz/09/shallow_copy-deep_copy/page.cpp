#include "page.h"

Page::Page(int no, int lines):m_no{no}
{
    for(int i = 0; i < lines; i++)
        _lines.push_back(new Line(i));
}

Page::Page(const Page &o):
    m_no{o.m_no}
{
    for(auto l:o._lines)
        _lines.push_back(new Line{*l});
}

//Page &Page::operator=(const Page &o)
//{
//    m_no = o.m_no;
//    for(auto l:_lines)
//        delete l;
//    _lines->clear();
//    for(auto l:o._lines)
//        _lines.push_back(new Line{*l});
//    return *this;
//}
